# GlobalSent backend deployment files

## What this backend supports
- `GET /api/health` checks API and PostgreSQL connectivity.
- `POST /api/auth/signup` creates an account.
- `POST /api/auth/signin` authenticates an account.
- `GET /api/auth/me` returns the signed-in user's profile.

It does not process real payments or perform real-money transfers. The QR transfer UI remains demo-only until a proper server-side ledger and approved payment partner are implemented.

## Deploy on Render
1. Upload `server.js`, `package.json`, `render.yaml`, and this README to the root of `nmjeeva34-spec/globalsent-backend`.
2. In Render, create a Blueprint from the repository.
3. Create a PostgreSQL database and set `DATABASE_URL` in the web service environment. Use the database's internal connection URL when available.
4. Set `JWT_SECRET` to a long random secret (at least 32 characters). Keep secrets out of GitHub and chat.
5. Set `ALLOWED_ORIGINS` to the exact frontend origin, e.g. `https://stately-caramel-778265.netlify.app`.
6. After deployment, open `https://YOUR-RENDER-SERVICE.onrender.com/api/health`. It should return `ok: true` and `database: connected`.

The frontend must be configured to call the deployed Render backend URL; do not use `localhost` in the public website.

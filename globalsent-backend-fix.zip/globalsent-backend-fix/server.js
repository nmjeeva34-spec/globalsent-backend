import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import pg from "pg";

const { Pool } = pg;
const app = express();
app.set("trust proxy", 1);
app.use(helmet());
app.use(cors({
  origin: (process.env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean),
  methods: ["GET", "POST", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));
app.use(express.json({ limit: "20kb" }));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false }));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "false" ? false : { rejectUnauthorized: false }
});
const jwtSecret = process.env.JWT_SECRET;
if (!process.env.DATABASE_URL || !jwtSecret || jwtSecret.length < 32) {
  console.error("Missing DATABASE_URL or JWT_SECRET (must be at least 32 characters).");
  process.exit(1);
}

await pool.query(`
CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
`);

function issueToken(user) {
  return jwt.sign({ sub: String(user.id), email: user.email }, jwtSecret, { expiresIn: "1h", issuer: "globalsent" });
}
function validEmail(email) {
  return typeof email === "string" && email.length <= 254 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ ok: true, service: "globalsent-auth", database: "connected", realPaymentsEnabled: false }); }
  catch { res.status(503).json({ ok: false, error: "Database unavailable" }); }
});

app.post("/api/auth/signup", async (req, res) => {
  try {
    const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (name.length < 2 || name.length > 100) return res.status(400).json({ error: "Enter a name between 2 and 100 characters." });
    if (!validEmail(email)) return res.status(400).json({ error: "Enter a valid email address." });
    if (password.length < 8 || password.length > 128) return res.status(400).json({ error: "Password must contain 8–128 characters." });
    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email",
      [name, email, passwordHash]
    );
    const user = result.rows[0];
    return res.status(201).json({ user, accessToken: issueToken(user), tokenType: "Bearer", expiresIn: 3600, emailVerified: false, note: "Email verification is not configured yet." });
  } catch (e) {
    if (e?.code === "23505") return res.status(409).json({ error: "An account with this email already exists." });
    console.error("signup failed", e?.message);
    return res.status(500).json({ error: "Could not create account. Please try again." });
  }
});

app.post("/api/auth/signin", async (req, res) => {
  try {
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!validEmail(email) || !password) return res.status(400).json({ error: "Enter your email and password." });
    const result = await pool.query("SELECT id,name,email,password_hash FROM users WHERE email=$1", [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
    const publicUser = { id: user.id, name: user.name, email: user.email };
    return res.json({ user: publicUser, accessToken: issueToken(publicUser), tokenType: "Bearer", expiresIn: 3600 });
  } catch (e) {
    console.error("signin failed", e?.message);
    return res.status(500).json({ error: "Could not sign in. Please try again." });
  }
});

app.get("/api/auth/me", async (req, res) => {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (!token) return res.status(401).json({ error: "Sign in required." });
    const decoded = jwt.verify(token, jwtSecret, { issuer: "globalsent" });
    const result = await pool.query("SELECT id,name,email FROM users WHERE id=$1", [decoded.sub]);
    if (!result.rows[0]) return res.status(401).json({ error: "Account not found." });
    res.json({ user: result.rows[0] });
  } catch { res.status(401).json({ error: "Session expired. Please sign in again." }); }
});

const port = Number(process.env.PORT || 8787);
app.listen(port, "0.0.0.0", () => console.log(`GlobalSent auth API listening on ${port}`));
